class QuizModel {
  String question;
  List<String> answers;

  QuizModel(this.question, this.answers);
}
